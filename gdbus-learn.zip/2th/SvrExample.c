#include "libServer.h"

int main(void)
{
    InitDBusCommunicationServer();

    sleep(100);

    return 0;
}
