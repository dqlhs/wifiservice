#ifndef YANLIN_GDBUS_EXAMPLE_H
#define YANLIN_GDBUS_EXAMPLE_H

#include <gio/gio.h> /* Bus define */

#define YANLIN_GDBUS_EXAMPLE_BUS         G_BUS_TYPE_SESSION
#define YANLIN_GDBUS_EXAMPLE_BUS_NAME    "com.yanlin.Gdbus.Example"
#define YANLIN_GDBUS_EXAMPLE_OBJECT_PATH "/com/yanlin/Gdbus/Example"

#endif

